chi chuyen vao thu muc nay.
run install.m
run add_path.m
		
usage : 
		run OPE_vs_GIST\least.m
		run OPE_vs_GIST\l2SVM.m
		run OPE_vs_GIST\logistic.m
