currentpath = cd;
addpath(genpath([currentpath,'/GIST']));
addpath(genpath([currentpath,'/OPE']));
addpath(genpath([currentpath,'/data']));
